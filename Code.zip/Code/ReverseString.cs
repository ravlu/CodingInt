﻿using System;

namespace ReverseString
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter User Input");
            string input = Console.ReadLine();

            for (int i = input.Length-1;  i >= 0; i--)
            {
                Console.Write(input[i]);
            }

        }
    }
}
