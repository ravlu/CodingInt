﻿using ProductOfferService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOfferService.Services
{
    public class OfferService : IOfferService
    {
        public OfferService()
        {
            this.Inventory = new List<Product>();
            this.AddPrdouctsToInventory();
        }

        private List<Product> Inventory { get; set; }

        private void AddPrdouctsToInventory() {
            this.Inventory.Add(new Product("P1",1000, "P1 Desc"));
            this.Inventory.Add(new Product("P2", 200, "P2 Desc"));
            this.Inventory.Add(new Product("P3", 400, "P3 Desc"));
            this.Inventory.Add(new Product("P4", 700, "P4 Desc"));
            this.Inventory.Add(new Product("P5", 600, "P5 Desc"));
            this.Inventory.Add(new Product("P6", 800, "P6 Desc"));
        }

        public List<Product> GetAllProducts() {
            return this.Inventory;
        }
        public List<Offer> GetTodaysOffers() {
            List<Offer> offers = new List<Offer>();
            offers.Add(CreateOfferWIthRandomProduct("ComboPackage1"));
            offers.Add(CreateOfferWIthRandomProduct("ComboPackage2"));
            offers.Add(CreateOfferWIthRandomProduct("ComboPackage3"));
            offers.Add(CreateOfferWIthRandomProduct("ComboPackage4"));
            return offers;
        }

        private Offer CreateOfferWIthRandomProduct(string name) {
           
            return new Offer(name, this.Inventory.Take(3).ToList());
        }
		public Product AddProduct(Product p){
			 this.Inventory.Add(p);
            return p;
		}
    }
}
