﻿using ProductOfferService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOfferService.Services
{
   public interface IOfferService
    {
        List<Product> GetAllProducts();
        List<Offer> GetTodaysOffers();

        Product AddProduct(Product p);
    }
}
