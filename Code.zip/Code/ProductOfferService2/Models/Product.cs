﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOfferService.Models
{
    public class Product
    {
        public Product(string name, decimal price,string desc)
        {
            ProductName = name;
            Price = price;
            Description = desc;
        }  

        public string ProductName { get; set; }

        public decimal Price { get; set; }

        public string Description { get; set; }
    }
}
