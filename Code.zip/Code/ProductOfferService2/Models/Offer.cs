﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOfferService.Models
{
    public class Offer
    {
        public Offer(string name, List<Product> products)
        {
            OfferName = name;
            Products = products;
        }

        public string OfferName { get; set; }

        public List<Product> Products { get; set; }
    }
}
