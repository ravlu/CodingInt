﻿using Microsoft.AspNetCore.Mvc;
using ProductOfferService.Models;
using ProductOfferService.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductOfferService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OfferController : ControllerBase
    {
        private readonly IOfferService _offerService;

        public OfferController(IOfferService offerService)
        {
            this._offerService = offerService;
        }

        // GET: api/<OfferController>
        [HttpGet]
        public List<Product> Get()
        {
            return this._offerService.GetAllProducts();
        }
        [HttpGet("GetOffers")]
        public List<Offer> GetTodaysOffers()
        {
            return this._offerService.GetTodaysOffers();
        }
        [HttpGet("GetTopThreeProducts")]
        public List<Product> GetTopThreeProducts()
        {
            return this._offerService.GetAllProducts().OrderBy(x => x.Price).Take(3).ToList();
        }
        [HttpGet("GetSecondLowestProduct")]
        public List<Product> GetSecondLowestProduct()
        {
            return this._offerService.GetAllProducts().OrderBy(x => x.Price).Skip(1).Take(1).ToList();
        }
        // GET api/<OfferController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<OfferController>
        [HttpPost]
        public Product Post(string name, decimal price, string desc )
        {
            return this._offerService.AddProduct(new Product(name, price,desc));
        }

        // PUT api/<OfferController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<OfferController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
